
# file: RadarBGT60TRxxE.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarBGT60TRxxE
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarBGT60TRxxE(EP):
    description = "ifxRadar BGT60TRxxE"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def pullup_resistor_configuration_callback(context, protocol_handle, endpoint, configuration):
        Configuration = namedtuple('Configuration', 'enable_spi_cs enable_spi_clk enable_spi_di enable_spi_do enable_spi_dio2 enable_spi_dio3 enable_irq')
        configuration_recv = Configuration(
            enable_spi_cs = configuration.enable_spi_cs,
            enable_spi_clk = configuration.enable_spi_clk,
            enable_spi_di = configuration.enable_spi_di,
            enable_spi_do = configuration.enable_spi_do,
            enable_spi_dio2 = configuration.enable_spi_dio2,
            enable_spi_dio3 = configuration.enable_spi_dio3,
            enable_irq = configuration.enable_irq
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"pullup_resistor_configuration"  
        EP.cb_recv[key_cbr] = configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_pullup_resistor_configuration_callback(self, pullup_resistor_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "pullup_resistor_configuration_callback_userlev", pullup_resistor_configuration_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_bgt60trxxe_set_callback_pullup_resistor_configuration(lib.pullup_resistor_configuration_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_bgt60trxxe_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def set_pullup_resistor_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxxe_set_pullup_resistor_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_pullup_resistor_configuration(self):
        lib.ep_radar_bgt60trxxe_set_callback_pullup_resistor_configuration(lib.pullup_resistor_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxe_get_pullup_resistor_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"pullup_resistor_configuration"]
