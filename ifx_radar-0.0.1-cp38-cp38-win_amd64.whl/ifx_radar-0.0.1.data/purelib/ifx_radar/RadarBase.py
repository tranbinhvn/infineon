
# file: RadarBase.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarBase
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarBase(EP):
    description = "ifxRadarBase"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def data_frame_callback(context, protocol_handle, endpoint, frame_info):
        element_size = 1 
        if frame_info.data_format != lib.EP_RADAR_BASE_RX_DATA_REAL: # I or Q signal 
                element_size = 2
        calc_size = frame_info.num_chirps * frame_info.num_rx_antennas *  \
                    frame_info.num_samples_per_chirp * element_size 
        Frame_Info = namedtuple('Frame_Info', 'sample_data_calc_array frame_number num_chirps num_rx_antennas num_samples_per_chirp rx_mask adc_resolution interleaved_rx data_format')
        frame_info_recv = Frame_Info(
            sample_data_calc_array = list(ffi.cast(" float[ %d ]"% calc_size, frame_info.sample_data)),
            frame_number = frame_info.frame_number,
            num_chirps = frame_info.num_chirps,
            num_rx_antennas = frame_info.num_rx_antennas,
            num_samples_per_chirp = frame_info.num_samples_per_chirp,
            rx_mask = frame_info.rx_mask,
            adc_resolution = frame_info.adc_resolution,
            interleaved_rx = frame_info.interleaved_rx,
            data_format = frame_info.data_format
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"data_frame"  
        EP.cb_recv[key_cbr] = frame_info_recv ## direct return mechanism ( no user callbacks is called ! )
        #
        user_callback = EP.get_user_callback(protocol_handle, "data_frame_callback_userlev")
        EP.joined_callback_wrapper_receiving_pars[str(protocol_handle)+str(endpoint)+"data_frame"] = frame_info_recv
        if user_callback is not None:
            user_callback(frame_info_recv)
        #

    def set_data_frame_callback(self, data_frame_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "data_frame_callback_userlev", data_frame_callback_userlev)

    @ffi.def_extern()
    def driver_version_callback(context, protocol_handle, endpoint, driver_version):
        Driver_Version = namedtuple('Driver_Version', 'major minor revision')
        driver_version_recv = Driver_Version(
            major = driver_version.major,
            minor = driver_version.minor,
            revision = driver_version.revision
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"driver_version"  
        EP.cb_recv[key_cbr] = driver_version_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_driver_version_callback(self, driver_version_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "driver_version_callback_userlev", driver_version_callback_userlev)

    @ffi.def_extern()
    def device_info_callback(context, protocol_handle, endpoint, device_info):
        Device_Info = namedtuple('Device_Info', 'description min_rf_frequency_kHz max_rf_frequency_kHz num_tx_antennas num_rx_antennas max_tx_power num_temp_sensors major_version_hw minor_version_hw interleaved_rx data_format')
        device_info_recv = Device_Info(
            description = device_info.description,
            min_rf_frequency_kHz = device_info.min_rf_frequency_kHz,
            max_rf_frequency_kHz = device_info.max_rf_frequency_kHz,
            num_tx_antennas = device_info.num_tx_antennas,
            num_rx_antennas = device_info.num_rx_antennas,
            max_tx_power = device_info.max_tx_power,
            num_temp_sensors = device_info.num_temp_sensors,
            major_version_hw = device_info.major_version_hw,
            minor_version_hw = device_info.minor_version_hw,
            interleaved_rx = device_info.interleaved_rx,
            data_format = device_info.data_format
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"device_info"  
        EP.cb_recv[key_cbr] = device_info_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_device_info_callback(self, device_info_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "device_info_callback_userlev", device_info_callback_userlev)

    @ffi.def_extern()
    def frame_format_callback(context, protocol_handle, endpoint, frame_format):
        Frame_Format = namedtuple('Frame_Format', 'num_samples_per_chirp num_chirps_per_frame rx_mask eSignalPart')
        frame_format_recv = Frame_Format(
            num_samples_per_chirp = frame_format.num_samples_per_chirp,
            num_chirps_per_frame = frame_format.num_chirps_per_frame,
            rx_mask = frame_format.rx_mask,
            eSignalPart = frame_format.eSignalPart
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"frame_format"  
        EP.cb_recv[key_cbr] = frame_format_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_frame_format_callback(self, frame_format_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "frame_format_callback_userlev", frame_format_callback_userlev)

    @ffi.def_extern()
    def temperature_callback(context, protocol_handle, endpoint, temp_sensor, temperature_001C):
        temp_sensor_recv = temp_sensor
        temperature_001C_recv = temperature_001C
        key_cbr = str(protocol_handle)+str(endpoint)+"temperature"  
        EP.cb_recv[key_cbr] = temp_sensor_recv, temperature_001C_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_temperature_callback(self, temperature_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "temperature_callback_userlev", temperature_callback_userlev)

    @ffi.def_extern()
    def tx_power_callback(context, protocol_handle, endpoint, tx_antenna, tx_power_001dBm):
        tx_antenna_recv = tx_antenna
        tx_power_001dBm_recv = tx_power_001dBm
        key_cbr = str(protocol_handle)+str(endpoint)+"tx_power"  
        EP.cb_recv[key_cbr] = tx_antenna_recv, tx_power_001dBm_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_tx_power_callback(self, tx_power_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "tx_power_callback_userlev", tx_power_callback_userlev)

    @ffi.def_extern()
    def chirp_duration_callback(context, protocol_handle, endpoint, chirp_duration_ns):
        chirp_duration_ns_recv = chirp_duration_ns
        key_cbr = str(protocol_handle)+str(endpoint)+"chirp_duration"  
        EP.cb_recv[key_cbr] = chirp_duration_ns_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_chirp_duration_callback(self, chirp_duration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "chirp_duration_callback_userlev", chirp_duration_callback_userlev)

    @ffi.def_extern()
    def min_frame_interval_callback(context, protocol_handle, endpoint, min_frame_interval_us):
        min_frame_interval_us_recv = min_frame_interval_us
        key_cbr = str(protocol_handle)+str(endpoint)+"min_frame_interval"  
        EP.cb_recv[key_cbr] = min_frame_interval_us_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_min_frame_interval_callback(self, min_frame_interval_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "min_frame_interval_callback_userlev", min_frame_interval_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_base_set_callback_data_frame(lib.data_frame_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_driver_version(lib.driver_version_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_device_info(lib.device_info_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_frame_format(lib.frame_format_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_temperature(lib.temperature_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_tx_power(lib.tx_power_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_chirp_duration(lib.chirp_duration_callback, ffi.NULL)
        lib.ep_radar_base_set_callback_min_frame_interval(lib.min_frame_interval_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_base_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def get_frame_data(self, wait):
        lib.ep_radar_base_set_callback_data_frame(lib.data_frame_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_frame_data(
                    self.communication_protocol_handle,
                    self.epindex,
                    wait))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"data_frame"]

    def set_automatic_frame_trigger(self, frame_interval_us):
        self.check_return_code(lib.ep_radar_base_set_automatic_frame_trigger(
                    self.communication_protocol_handle,
                    self.epindex,
                    frame_interval_us))

    def enable_test_mode(self, tx_mask, rx_mask, frequency_kHz, tx_power):
        self.check_return_code(lib.ep_radar_base_enable_test_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    tx_mask,
                     rx_mask,
                     frequency_kHz,
                     tx_power))

    def get_driver_version(self):
        lib.ep_radar_base_set_callback_driver_version(lib.driver_version_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_driver_version(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"driver_version"]

    def get_device_info(self):
        lib.ep_radar_base_set_callback_device_info(lib.device_info_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_device_info(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"device_info"]

    def set_frame_format(self, frame_format_cffi_struct):
        self.check_return_code(lib.ep_radar_base_set_frame_format(
                    self.communication_protocol_handle,
                    self.epindex,
                    frame_format_cffi_struct))

    def get_frame_format(self):
        lib.ep_radar_base_set_callback_frame_format(lib.frame_format_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_frame_format(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"frame_format"]

    def get_temperature(self, temp_sensor):
        lib.ep_radar_base_set_callback_temperature(lib.temperature_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_temperature(
                    self.communication_protocol_handle,
                    self.epindex,
                    temp_sensor))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"temperature"]

    def get_tx_power(self, tx_antenna):
        lib.ep_radar_base_set_callback_tx_power(lib.tx_power_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_tx_power(
                    self.communication_protocol_handle,
                    self.epindex,
                    tx_antenna))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"tx_power"]

    def get_chirp_duration(self):
        lib.ep_radar_base_set_callback_chirp_duration(lib.chirp_duration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_chirp_duration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"chirp_duration"]

    def get_min_frame_interval(self):
        lib.ep_radar_base_set_callback_min_frame_interval(lib.min_frame_interval_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_base_get_min_frame_interval(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"min_frame_interval"]
