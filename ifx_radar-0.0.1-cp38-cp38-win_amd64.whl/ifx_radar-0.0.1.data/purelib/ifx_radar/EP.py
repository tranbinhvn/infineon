"""
 * file: EP.py
 *
 * This python class contains the base class encapsulating
 * common functions and code for all * derived endpoint classes  
 *
** ===========================================================================
** Copyright (C) 2014-2021 Infineon Technologies AG
** All rights reserved.
** ===========================================================================
**
** ===========================================================================
** This document contains proprietary information of Infineon Technologies AG.
** Passing on and copying of this document, and communication of its contents
** is not permitted without Infineon's prior written authorisation.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
"""
from . import ffi, lib

class EP:
    def __init__(self, communication_protocol_handle, epindex):
        self.communication_protocol_handle = communication_protocol_handle
        self.epindex = epindex
        self.is_compatible_endpoint()
        #self.setup_callbacks()  ###  not any more -- automatic_registration_when needed  
        EP.user_callback = {} # multi-sensor board support
        EP.joined_callback_wrapper_receiving_pars = {} # all the info containing incoming params of a callback wrapper    
        EP.cb_recv = {} # avoid callback mechanism and return value to the user directly if get_* api function is used 

    def get_user_callback(handle, user_callback_name):
        #print("get_user_callback():")
        #EP.print_user_callback()
        try:
            return EP.user_callback[str(handle)+user_callback_name] 
        except:
            print("no callback was registered before by the user for %s \n" % (user_callback_name.replace("_userlev", "")))
            #EP.print_user_callback()
            return None

    def print_user_callback():
        for k,v in EP.user_callback.items():
            print("..............user reg.................[%s] " % (k))

    def set_user_callback(handle, user_callback_name, function_ptr):
        EP.user_callback[str(handle)+user_callback_name] = function_ptr
        print("set_user_callback():")
        EP.print_user_callback()

    def is_compatible_endpoint(self):
        pass

    def setup_callbacks(self):
        pass  

    def human_readable_error_code(self, return_code):
        return_code_txt = lib.protocol_get_status_code_description(self.communication_protocol_handle, return_code)
        return_bstr = ffi.string(return_code_txt)
        return_str = str(return_bstr, 'utf-8')
        raise Exception(return_str)
    
    def check_return_code(self, return_code):
        if (return_code & 0xFFFF != 0):
            self.human_readable_error_code(return_code) 


    


