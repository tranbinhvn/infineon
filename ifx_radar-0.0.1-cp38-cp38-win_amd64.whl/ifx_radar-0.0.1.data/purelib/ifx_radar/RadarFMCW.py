
# file: RadarFMCW.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarFMCW
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarFMCW(EP):
    description = "ifxRadar FMCW"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def fmcw_configuration_callback(context, protocol_handle, endpoint, fmcw_configuration):
        Fmcw_Configuration = namedtuple('Fmcw_Configuration', 'lower_frequency_kHz upper_frequency_kHz direction tx_power')
        fmcw_configuration_recv = Fmcw_Configuration(
            lower_frequency_kHz = fmcw_configuration.lower_frequency_kHz,
            upper_frequency_kHz = fmcw_configuration.upper_frequency_kHz,
            direction = fmcw_configuration.direction,
            tx_power = fmcw_configuration.tx_power
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"fmcw_configuration"  
        EP.cb_recv[key_cbr] = fmcw_configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_fmcw_configuration_callback(self, fmcw_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "fmcw_configuration_callback_userlev", fmcw_configuration_callback_userlev)

    @ffi.def_extern()
    def bandwidth_per_second_callback(context, protocol_handle, endpoint, bandwidth_per_second):
        bandwidth_per_second_recv = bandwidth_per_second
        key_cbr = str(protocol_handle)+str(endpoint)+"bandwidth_per_second"  
        EP.cb_recv[key_cbr] = bandwidth_per_second_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_bandwidth_per_second_callback(self, bandwidth_per_second_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "bandwidth_per_second_callback_userlev", bandwidth_per_second_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_fmcw_set_callback_fmcw_configuration(lib.fmcw_configuration_callback, ffi.NULL)
        lib.ep_radar_fmcw_set_callback_bandwidth_per_second(lib.bandwidth_per_second_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_fmcw_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def set_fmcw_configuration(self, fmcw_configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_fmcw_set_fmcw_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    fmcw_configuration_cffi_struct))

    def get_fmcw_configuration(self):
        lib.ep_radar_fmcw_set_callback_fmcw_configuration(lib.fmcw_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_fmcw_get_fmcw_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"fmcw_configuration"]

    def get_bandwidth_per_second(self):
        lib.ep_radar_fmcw_set_callback_bandwidth_per_second(lib.bandwidth_per_second_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_fmcw_get_bandwidth_per_second(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"bandwidth_per_second"]
