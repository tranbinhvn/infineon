
# file: RadarBGT60TRxx.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarBGT60TRxx
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarBGT60TRxx(EP):
    description = "ifxRadar BGT60TRxx"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def frame_definition_callback(context, protocol_handle, endpoint, frame_definition):
        #print("%s is CALLED-BACK from c-API" % ("frame_definition_callback(context, protocol_handle, endpoint, frame_definition"))
        Shape_Set = namedtuple('Shape_Set', 'num_repetitions following_power_mode post_delay_100ps')
        Frame_Definition = namedtuple('Frame_Definition', 'shapes_array shape_set num_frames')

        #shapes_array_man = list(ffi.cast("Shape_Group_t[4]", frame_definition.shapes))
        
        shapes_array_man = []


        shapes_array_man_0 = Shape_Set(
            num_repetitions = frame_definition.shapes[0].num_repetitions,
            following_power_mode = frame_definition.shapes[0].following_power_mode,
            post_delay_100ps = frame_definition.shapes[0].post_delay_100ps
            )

        shapes_array_man_1 = Shape_Set(
            num_repetitions = frame_definition.shapes[1].num_repetitions,
            following_power_mode = frame_definition.shapes[1].following_power_mode,
            post_delay_100ps = frame_definition.shapes[1].post_delay_100ps
            )

        shapes_array_man_2 = Shape_Set(
            num_repetitions = frame_definition.shapes[2].num_repetitions,
            following_power_mode = frame_definition.shapes[2].following_power_mode,
            post_delay_100ps = frame_definition.shapes[2].post_delay_100ps
            )

        shapes_array_man_3 = Shape_Set(
            num_repetitions = frame_definition.shapes[3].num_repetitions,
            following_power_mode = frame_definition.shapes[3].following_power_mode,
            post_delay_100ps = frame_definition.shapes[3].post_delay_100ps
            )
        shapes_array_man.append(shapes_array_man_0)
        shapes_array_man.append(shapes_array_man_1)
        shapes_array_man.append(shapes_array_man_2)
        shapes_array_man.append(shapes_array_man_3)

        shape_set_man = Shape_Set(
            num_repetitions = frame_definition.shape_set.num_repetitions,
            following_power_mode = frame_definition.shape_set.following_power_mode,
            post_delay_100ps = frame_definition.shape_set.post_delay_100ps
            )        
                
        frame_definition_recv = Frame_Definition(
            shapes_array = shapes_array_man,
            shape_set = shape_set_man,
            num_frames = frame_definition.num_frames
            )


        key_cbr = str(protocol_handle)+str(endpoint)+"frame_definition"  
        EP.cb_recv[key_cbr] = frame_definition_recv ## direct return mechanism ( no user callbacks ! )

    @ffi.def_extern()
    def selected_shape_callback(context, protocol_handle, endpoint, shape, down_chirp):
        shape_recv = shape
        down_chirp_recv = down_chirp
        key_cbr = str(protocol_handle)+str(endpoint)+"selected_shape"  
        EP.cb_recv[key_cbr] = shape_recv, down_chirp_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_selected_shape_callback(self, selected_shape_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "selected_shape_callback_userlev", selected_shape_callback_userlev)

    @ffi.def_extern()
    def chirp_timing_callback(context, protocol_handle, endpoint, timing):
        Timing = namedtuple('Timing', 'pre_chirp_delay_100ps post_chirp_delay_100ps pa_delay_100ps adc_delay_100ps')
        timing_recv = Timing(
            pre_chirp_delay_100ps = timing.pre_chirp_delay_100ps,
            post_chirp_delay_100ps = timing.post_chirp_delay_100ps,
            pa_delay_100ps = timing.pa_delay_100ps,
            adc_delay_100ps = timing.adc_delay_100ps
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"chirp_timing"  
        EP.cb_recv[key_cbr] = timing_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_chirp_timing_callback(self, chirp_timing_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "chirp_timing_callback_userlev", chirp_timing_callback_userlev)

    @ffi.def_extern()
    def startup_timing_callback(context, protocol_handle, endpoint, timing):
        Timing = namedtuple('Timing', 'wake_up_time_100ps pll_settle_time_coarse_100ps pll_settle_time_fine_100ps')
        timing_recv = Timing(
            wake_up_time_100ps = timing.wake_up_time_100ps,
            pll_settle_time_coarse_100ps = timing.pll_settle_time_coarse_100ps,
            pll_settle_time_fine_100ps = timing.pll_settle_time_fine_100ps
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"startup_timing"  
        EP.cb_recv[key_cbr] = timing_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_startup_timing_callback(self, startup_timing_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "startup_timing_callback_userlev", startup_timing_callback_userlev)

    @ffi.def_extern()
    def chirp_end_delay_callback(context, protocol_handle, endpoint, chirp_end_delay):
        chirp_end_delay_recv = chirp_end_delay
        key_cbr = str(protocol_handle)+str(endpoint)+"chirp_end_delay"  
        EP.cb_recv[key_cbr] = chirp_end_delay_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_chirp_end_delay_callback(self, chirp_end_delay_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "chirp_end_delay_callback_userlev", chirp_end_delay_callback_userlev)

    @ffi.def_extern()
    def power_down_configuration_callback(context, protocol_handle, endpoint, configuration):
        Configuration = namedtuple('Configuration', 'enable_pll enable_vco enable_fdiv enable_baseband enable_rf enable_madc enable_madc_bandgap enable_sadc enable_sadc_bandgap')
        configuration_recv = Configuration(
            enable_pll = configuration.enable_pll,
            enable_vco = configuration.enable_vco,
            enable_fdiv = configuration.enable_fdiv,
            enable_baseband = configuration.enable_baseband,
            enable_rf = configuration.enable_rf,
            enable_madc = configuration.enable_madc,
            enable_madc_bandgap = configuration.enable_madc_bandgap,
            enable_sadc = configuration.enable_sadc,
            enable_sadc_bandgap = configuration.enable_sadc_bandgap
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"power_down_configuration"  
        EP.cb_recv[key_cbr] = configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_power_down_configuration_callback(self, power_down_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "power_down_configuration_callback_userlev", power_down_configuration_callback_userlev)

    @ffi.def_extern()
    def data_slice_size_callback(context, protocol_handle, endpoint, slice_size):
        slice_size_recv = slice_size
        key_cbr = str(protocol_handle)+str(endpoint)+"data_slice_size"  
        EP.cb_recv[key_cbr] = slice_size_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_data_slice_size_callback(self, data_slice_size_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "data_slice_size_callback_userlev", data_slice_size_callback_userlev)

    @ffi.def_extern()
    def slice_data_callback(context, protocol_handle, endpoint, slice_data, num_samples):
        slice_data_recv = list(ffi.cast(" float[%d]" % num_samples, slice_data))
        num_samples_recv = num_samples
        key_cbr = str(protocol_handle)+str(endpoint)+"slice_data"  
        EP.cb_recv[key_cbr] = slice_data_recv, num_samples_recv ## direct return mechanism ( no user callbacks is called ! )
        #
        user_callback = EP.get_user_callback(protocol_handle, "slice_data_callback_userlev")
        EP.joined_callback_wrapper_receiving_pars[str(protocol_handle)+str(endpoint)+"slice_data"] = slice_data_recv, num_samples_recv
        if user_callback is not None:
            user_callback(slice_data_recv, num_samples_recv)
        #

    def set_slice_data_callback(self, slice_data_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "slice_data_callback_userlev", slice_data_callback_userlev)

    @ffi.def_extern()
    def device_id_callback(context, protocol_handle, endpoint, device_id):
        device_id_recv = device_id
        key_cbr = str(protocol_handle)+str(endpoint)+"device_id"  
        EP.cb_recv[key_cbr] = device_id_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_device_id_callback(self, device_id_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "device_id_callback_userlev", device_id_callback_userlev)

    @ffi.def_extern()
    def reference_clock_frequency_callback(context, protocol_handle, endpoint, frequency):
        frequency_recv = frequency
        key_cbr = str(protocol_handle)+str(endpoint)+"reference_clock_frequency"  
        EP.cb_recv[key_cbr] = frequency_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_reference_clock_frequency_callback(self, reference_clock_frequency_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "reference_clock_frequency_callback_userlev", reference_clock_frequency_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_bgt60trxx_set_callback_frame_definiton(lib.frame_definition_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_selected_shape(lib.selected_shape_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_chirp_timing(lib.chirp_timing_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_startup_timing(lib.startup_timing_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_chirp_end_delay(lib.chirp_end_delay_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_idle_mode_config(lib.power_down_configuration_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_deep_sleep_mode_config(lib.power_down_configuration_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_data_slice_size(lib.data_slice_size_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_slice_data(lib.slice_data_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_device_id(lib.device_id_callback, ffi.NULL)
        lib.ep_radar_bgt60trxx_set_callback_reference_clock_frequency(lib.reference_clock_frequency_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_bgt60trxx_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def trigger_sequence(self):
        self.check_return_code(lib.ep_radar_bgt60trxx_trigger_sequence(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))

    def stop_and_reset_sequence(self):
        self.check_return_code(lib.ep_radar_bgt60trxx_stop_and_reset_sequence(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))

    def set_frame_definition(self, frame_definition_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_frame_definition(
                    self.communication_protocol_handle,
                    self.epindex,
                    frame_definition_cffi_struct))

    def get_frame_definition(self):
        lib.ep_radar_bgt60trxx_set_callback_frame_definiton(lib.frame_definition_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_frame_definition(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"frame_definition"]

    def select_shape_to_configure(self, shape, downChirp):
        lib.ep_radar_bgt60trxx_set_callback_selected_shape(lib.selected_shape_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_select_shape_to_configure(
                    self.communication_protocol_handle,
                    self.epindex,
                    shape,
                     downChirp))

    def get_selected_shape(self):
        lib.ep_radar_bgt60trxx_set_callback_selected_shape(lib.selected_shape_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_selected_shape(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"selected_shape"]

    def set_chirp_timing(self, timing_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_chirp_timing(
                    self.communication_protocol_handle,
                    self.epindex,
                    timing_cffi_struct))

    def get_chirp_timing(self):
        lib.ep_radar_bgt60trxx_set_callback_chirp_timing(lib.chirp_timing_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_chirp_timing(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"chirp_timing"]

    def set_startup_timing(self, timing_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_startup_timing(
                    self.communication_protocol_handle,
                    self.epindex,
                    timing_cffi_struct))

    def get_startup_timing(self):
        lib.ep_radar_bgt60trxx_set_callback_startup_timing(lib.startup_timing_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_startup_timing(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"startup_timing"]

    def set_chirp_end_delay(self, delay_100ps):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_chirp_end_delay(
                    self.communication_protocol_handle,
                    self.epindex,
                    delay_100ps))

    def get_chirp_end_delay(self):
        lib.ep_radar_bgt60trxx_set_callback_chirp_end_delay(lib.chirp_end_delay_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_chirp_end_delay(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"chirp_end_delay"]

    def set_idle_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_idle_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_idle_configuration(self):
        lib.ep_radar_bgt60trxx_set_callback_idle_mode_config(lib.power_down_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_idle_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"power_down_configuration"]

    def set_deep_sleep_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_deep_sleep_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_deep_sleep_configuration(self):
        lib.ep_radar_bgt60trxx_set_callback_deep_sleep_mode_config(lib.power_down_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_deep_sleep_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"power_down_configuration"]

    def get_data_slice_size(self):
        lib.ep_radar_bgt60trxx_set_callback_data_slice_size(lib.data_slice_size_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_data_slice_size(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"data_slice_size"]

    def set_data_slice_size(self, slice_size):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_data_slice_size(
                    self.communication_protocol_handle,
                    self.epindex,
                    slice_size))

    def get_next_data_slice(self, wait):
        lib.ep_radar_bgt60trxx_set_callback_slice_data(lib.slice_data_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_next_data_slice(
                    self.communication_protocol_handle,
                    self.epindex,
                    wait))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"slice_data"]

    def enable_easy_mode(self, enable):
        self.check_return_code(lib.ep_radar_bgt60trxx_enable_easy_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    enable))

    def test_spi_connection(self):
        self.check_return_code(lib.ep_radar_bgt60trxx_test_spi_connection(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))

    def test_fifo_memory(self):
        self.check_return_code(lib.ep_radar_bgt60trxx_test_fifo_memory(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))

    def repeat_chip_setup(self):
        self.check_return_code(lib.ep_radar_bgt60trxx_repeat_chip_setup(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))

    def get_device_id(self):
        lib.ep_radar_bgt60trxx_set_callback_device_id(lib.device_id_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_device_id(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"device_id"]

    def set_reference_clock_frequency(self, frequency):
        self.check_return_code(lib.ep_radar_bgt60trxx_set_reference_clock_frequency(
                    self.communication_protocol_handle,
                    self.epindex,
                    frequency))

    def get_reference_clock_frequency(self):
        lib.ep_radar_bgt60trxx_set_callback_reference_clock_frequency(lib.reference_clock_frequency_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxx_get_reference_clock_frequency(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"reference_clock_frequency"]
