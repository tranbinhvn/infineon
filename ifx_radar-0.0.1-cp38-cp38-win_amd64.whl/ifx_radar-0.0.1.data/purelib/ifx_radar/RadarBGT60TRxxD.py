
# file: RadarBGT60TRxxD.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarBGT60TRxxD
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarBGT60TRxxD(EP):
    description = "ifxRadar BGT60TRxxD"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def startup_delays_callback(context, protocol_handle, endpoint, delays):
        Delays = namedtuple('Delays', 'bandgap_100ps madc_100ps pll_enable_100ps pll_divider_100ps')
        delays_recv = Delays(
            bandgap_100ps = delays.bandgap_100ps,
            madc_100ps = delays.madc_100ps,
            pll_enable_100ps = delays.pll_enable_100ps,
            pll_divider_100ps = delays.pll_divider_100ps
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"startup_delays"  
        EP.cb_recv[key_cbr] = delays_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_startup_delays_callback(self, startup_delays_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "startup_delays_callback_userlev", startup_delays_callback_userlev)

    @ffi.def_extern()
    def anti_alias_filter_settings_callback(context, protocol_handle, endpoint, settings):
        Settings = namedtuple('Settings', 'frequency1 frequency2 frequency3 frequency4')
        settings_recv = Settings(
            frequency1 = settings.frequency1,
            frequency2 = settings.frequency2,
            frequency3 = settings.frequency3,
            frequency4 = settings.frequency4
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"anti_alias_filter_settings"  
        EP.cb_recv[key_cbr] = settings_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_anti_alias_filter_settings_callback(self, anti_alias_filter_settings_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "anti_alias_filter_settings_callback_userlev", anti_alias_filter_settings_callback_userlev)

    @ffi.def_extern()
    def fifo_power_mode_callback(context, protocol_handle, endpoint, mode):
        mode_recv = mode
        key_cbr = str(protocol_handle)+str(endpoint)+"fifo_power_mode"  
        EP.cb_recv[key_cbr] = mode_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_fifo_power_mode_callback(self, fifo_power_mode_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "fifo_power_mode_callback_userlev", fifo_power_mode_callback_userlev)

    @ffi.def_extern()
    def pad_driver_mode_callback(context, protocol_handle, endpoint, mode):
        mode_recv = mode
        key_cbr = str(protocol_handle)+str(endpoint)+"pad_driver_mode"  
        EP.cb_recv[key_cbr] = mode_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_pad_driver_mode_callback(self, pad_driver_mode_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "pad_driver_mode_callback_userlev", pad_driver_mode_callback_userlev)

    @ffi.def_extern()
    def tx_toggle_settings_callback(context, protocol_handle, endpoint, settings):
        Settings = namedtuple('Settings', 'mode frequency_Hz')
        settings_recv = Settings(
            mode = settings.mode,
            frequency_Hz = settings.frequency_Hz
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"tx_toggle_settings"  
        EP.cb_recv[key_cbr] = settings_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_tx_toggle_settings_callback(self, tx_toggle_settings_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "tx_toggle_settings_callback_userlev", tx_toggle_settings_callback_userlev)

    @ffi.def_extern()
    def duty_cycle_correction_callback(context, protocol_handle, endpoint, settings):
        Settings = namedtuple('Settings', 'mode invert_input adjust_in adjust_out')
        settings_recv = Settings(
            mode = settings.mode,
            invert_input = settings.invert_input,
            adjust_in = settings.adjust_in,
            adjust_out = settings.adjust_out
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"duty_cycle_correction"  
        EP.cb_recv[key_cbr] = settings_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_duty_cycle_correction_callback(self, duty_cycle_correction_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "duty_cycle_correction_callback_userlev", duty_cycle_correction_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_bgt60trxxd_set_callback_startup_delays(lib.startup_delays_callback, ffi.NULL)
        lib.ep_radar_bgt60trxxd_set_callback_anti_alias_filter_settings(lib.anti_alias_filter_settings_callback, ffi.NULL)
        lib.ep_radar_bgt60trxxd_set_callback_fifo_power_mode(lib.fifo_power_mode_callback, ffi.NULL)
        lib.ep_radar_bgt60trxxd_set_callback_pad_driver_mode(lib.pad_driver_mode_callback, ffi.NULL)
        lib.ep_radar_bgt60trxxd_set_callback_tx_toggle_settings(lib.tx_toggle_settings_callback, ffi.NULL)
        lib.ep_radar_bgt60trxxd_set_callback_duty_cycle_correction(lib.duty_cycle_correction_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_bgt60trxxd_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def set_startup_delays(self, delays_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxxd_set_startup_delays(
                    self.communication_protocol_handle,
                    self.epindex,
                    delays_cffi_struct))

    def get_startup_delays(self):
        lib.ep_radar_bgt60trxxd_set_callback_startup_delays(lib.startup_delays_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxd_get_startup_delays(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"startup_delays"]

    def set_anti_alias_filter_settings(self, settings_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxxd_set_anti_alias_filter_settings(
                    self.communication_protocol_handle,
                    self.epindex,
                    settings_cffi_struct))

    def get_anti_alias_filter_settings(self):
        lib.ep_radar_bgt60trxxd_set_callback_anti_alias_filter_settings(lib.anti_alias_filter_settings_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxd_get_anti_alias_filter_settings(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"anti_alias_filter_settings"]

    def set_fifo_power_mode(self, mode):
        self.check_return_code(lib.ep_radar_bgt60trxxd_set_fifo_power_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    mode))

    def get_fifo_power_mode(self):
        lib.ep_radar_bgt60trxxd_set_callback_fifo_power_mode(lib.fifo_power_mode_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxd_get_fifo_power_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"fifo_power_mode"]

    def set_pad_driver_mode(self, mode):
        self.check_return_code(lib.ep_radar_bgt60trxxd_set_pad_driver_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    mode))

    def get_pad_driver_mode(self):
        lib.ep_radar_bgt60trxxd_set_callback_pad_driver_mode(lib.pad_driver_mode_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxd_get_pad_driver_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"pad_driver_mode"]

    def set_tx_toggle_settings(self, settings_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxxd_set_tx_toggle_settings(
                    self.communication_protocol_handle,
                    self.epindex,
                    settings_cffi_struct))

    def get_tx_toggle_settings(self):
        lib.ep_radar_bgt60trxxd_set_callback_tx_toggle_settings(lib.tx_toggle_settings_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxd_get_tx_toggle_settings(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"tx_toggle_settings"]

    def set_duty_cycle_correction(self, settings_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt60trxxd_set_duty_cycle_correction(
                    self.communication_protocol_handle,
                    self.epindex,
                    settings_cffi_struct))

    def get_duty_cycle_correction(self):
        lib.ep_radar_bgt60trxxd_set_callback_duty_cycle_correction(lib.duty_cycle_correction_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60trxxd_get_duty_cycle_correction(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"duty_cycle_correction"]
