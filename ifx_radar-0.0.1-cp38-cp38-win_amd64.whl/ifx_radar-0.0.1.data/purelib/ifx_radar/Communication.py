"""
 * file: Communication.py
 *
 * This python class suppposed to encapsulate all
 * for using a serial port to access the sensor device over USB connection
 *
** ===========================================================================
** Copyright (C) 2014-2021 Infineon Technologies AG
** All rights reserved.
** ===========================================================================
**
** ===========================================================================
** This document contains proprietary information of Infineon Technologies AG.
** Passing on and copying of this document, and communication of its contents
** is not permitted without Infineon's prior written authorisation.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
** INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
** CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
** ===========================================================================
"""
##############################################################
#"""
#                      I M P O R T S
#"""
###############################################################
from . import *

class Communication:
    def __init__(self, user_given_port=None):
        self.eps = {}
        if user_given_port is not None:
            self.port = user_given_port
        else:
            self.port = type(self).get_port_list()[0]
        self.protocol_connection()
        self.say_eps()

    def get_port_list():
        #This function returns a list of available COM ports.
        #returns a list of the names of available ports
        BUFFER_SIZE = 512  # TODO: consider changing how this works so the buffer expands
        port_list = ffi.new("char[512]")
        count = lib.com_get_port_list(port_list, BUFFER_SIZE-1)
        port_list = ffi.string(port_list).decode("utf-8")
        if port_list:
            return port_list.split(';')
        else:
            return []

    def destroy(self):
        for k,ep in self.eps.items():
            print("delete %s" % self.details(ep))
            del ep
        del self.eps
        type(self).disconnect(self.communication_protocol_handle)

    def say_eps(self):
        print("\n-----------------------\n")
        print("\nAll EP objects created:\n")
        for k,v in self.eps.items():
            print("%s" % (self.details(v)))
        print("\n-----------------------\n")

    def details(self, epi):
        return "hndl[%d]--%s:EP[%s] %s" % (self.communication_protocol_handle, self.port, epi.epindex, epi.description)

    def connect(port_name):
        handle = lib.protocol_connect(port_name.encode('utf-8'))
        if handle < 0:
            raise Exception("Communication.connect() exception : port %s is NOT connected" % port_name)
        return handle

    def disconnect(handle):
        lib.protocol_disconnect(handle)

    def get_num_endpoints(handle):
        num_endpoints = lib.protocol_get_num_endpoints(handle)
        if num_endpoints < 0:  # less then zero means error
            raise ProtocolError(handle, num_endpoints)
        return num_endpoints


    def get_firmware_version(handle):
        version_list = ffi.new("uint16_t[3]")
        status_code = lib.protocol_get_firmware_version(handle, ffi.addressof(version_list))
        if status_code != 0:  # non-zero means error
            raise ProtocolError(handle, status_code)
        return tuple(version_list)


    def get_endpoint_info(handle, endpoint_index):
        info_cffi = ffi.new("Endpoint_Info_t*")
        status_code = lib.protocol_get_endpoint_info(handle, endpoint_index, info_cffi)
        if status_code < 0:  # less then zero means error
            raise ProtocolError(handle, status_code)
        return info_cffi.type, info_cffi.version, str(ffi.string(info_cffi.description), 'utf-8')


    def get_status_code_description(handle, status_code):
        message = lib.protocol_get_status_code_description(handle, status_code)
        return message


    def protocol_connection(self):
        print("port will be tried to get connected to: ", self.port)
        communication_protocol_handle = type(self).connect(self.port)
        num_endpoints_in_handle = type(self).get_num_endpoints(communication_protocol_handle)
        self.communication_protocol_handle = communication_protocol_handle
        self.number_of_eps = num_endpoints_in_handle
        # iterate over the endpoints
        for epindex in range(1, num_endpoints_in_handle + 1):
            eptype, epversion, epdescription = type(self).get_endpoint_info(communication_protocol_handle, epindex)
            print("what comlib reports:", eptype, epversion, epdescription)
            if len(epdescription) > 0:
                if epdescription.find(RadarBase.description) > -1:
                    self.RadarBase = RadarBase(communication_protocol_handle, epindex)
                    self.eps[RadarBase.description] = self.RadarBase
                elif epdescription.find(RadarFMCW.description) > -1:
                    self.RadarFMCW = RadarFMCW(communication_protocol_handle, epindex)
                    self.eps[RadarFMCW.description] = self.RadarFMCW
                elif epdescription.find(RadarBGT6x.description) > -1:
                    self.RadarBGT6x = RadarBGT6x(communication_protocol_handle, epindex)
                    self.eps[RadarBGT6x.description] = self.RadarBGT6x
                elif epdescription.find(RadarBGT60TRxxD.description) > -1:
                    self.RadarBGT60TRxxD = RadarBGT60TRxxD(communication_protocol_handle, epindex)
                    self.eps[RadarBGT60TRxxD.description] = self.RadarBGT60TRxxD
                elif epdescription.find(RadarBGT60TRxxE.description) > -1:
                    self.RadarBGT60TRxxE = RadarBGT60TRxxE(communication_protocol_handle, epindex)
                    self.eps[RadarBGT60TRxxE.description] = self.RadarBGT60TRxxE
                elif epdescription.find(RadarBGT60TR11D.description) > -1:
                    self.RadarBGT60TR11D = RadarBGT60TR11D(communication_protocol_handle, epindex)
                    self.eps[RadarBGT60TR11D.description] = self.RadarBGT60TR11D
                elif epdescription.find(HALBGT60TRxx.description) > -1:
                    self.HALBGT60TRxx = HALBGT60TRxx(communication_protocol_handle, epindex)
                    self.eps[HALBGT60TRxx.description] = self.HALBGT60TRxx
                elif epdescription.find(RadarBGT60TRxx.description) > -1:
                    self.RadarBGT60TRxx = RadarBGT60TRxx(communication_protocol_handle, epindex)
                    self.eps[RadarBGT60TRxx.description] = self.RadarBGT60TRxx
                else:
                    print("unknown EP description is encountered ! Please Clarify : %s" % epdescription)
