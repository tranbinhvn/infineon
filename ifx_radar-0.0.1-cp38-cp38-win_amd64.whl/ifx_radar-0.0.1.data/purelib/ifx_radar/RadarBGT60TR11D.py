
# file: RadarBGT60TR11D.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarBGT60TR11D
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarBGT60TR11D(EP):
    description = "ifxRadar BGT60TR11D"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def power_sens_delays_callback(context, protocol_handle, endpoint, delay_100ps):
        delay_100ps_recv = delay_100ps
        key_cbr = str(protocol_handle)+str(endpoint)+"power_sens_delays"  
        EP.cb_recv[key_cbr] = delay_100ps_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_power_sens_delays_callback(self, power_sens_delays_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "power_sens_delays_callback_userlev", power_sens_delays_callback_userlev)

    @ffi.def_extern()
    def sens_enabled_callback(context, protocol_handle, endpoint, enabled):
        enabled_recv = enabled
        key_cbr = str(protocol_handle)+str(endpoint)+"sens_enabled"  
        EP.cb_recv[key_cbr] = enabled_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_sens_enabled_callback(self, sens_enabled_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "sens_enabled_callback_userlev", sens_enabled_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_bgt60tr11d_set_callback_power_sens_delay(lib.power_sens_delays_callback, ffi.NULL)
        lib.ep_radar_bgt60tr11d_set_callback_power_sens_enabled(lib.sens_enabled_callback, ffi.NULL)
        lib.ep_radar_bgt60tr11d_set_callback_temperature_sens_enabled(lib.sens_enabled_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_bgt60tr11d_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def set_power_sens_delay(self, delay_100ps):
        self.check_return_code(lib.ep_radar_bgt60tr11d_set_power_sens_delay(
                    self.communication_protocol_handle,
                    self.epindex,
                    delay_100ps))

    def get_power_sens_delay(self):
        lib.ep_radar_bgt60tr11d_set_callback_power_sens_delay(lib.power_sens_delays_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60tr11d_get_power_sens_delay(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"power_sens_delays"]

    def set_power_sens_enabled(self, enabled):
        self.check_return_code(lib.ep_radar_bgt60tr11d_set_power_sens_enabled(
                    self.communication_protocol_handle,
                    self.epindex,
                    enabled))

    def get_power_sens_enabled(self):
        lib.ep_radar_bgt60tr11d_set_callback_power_sens_enabled(lib.sens_enabled_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60tr11d_get_power_sens_enabled(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"sens_enabled"]

    def set_temperature_sens_enabled(self, enabled):
        self.check_return_code(lib.ep_radar_bgt60tr11d_set_temperature_sens_enabled(
                    self.communication_protocol_handle,
                    self.epindex,
                    enabled))

    def get_temperature_sens_enabled(self):
        lib.ep_radar_bgt60tr11d_set_callback_temperature_sens_enabled(lib.sens_enabled_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt60tr11d_get_temperature_sens_enabled(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"sens_enabled"]
