
# file: HALBGT60TRxx.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointHALBGT60TRxx
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class HALBGT60TRxx(EP):
    description = "Hardware Abstraction Layer (HAL) for BGT60TRxx"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def register_readback_callback(context, protocol_handle, endpoint, register_words, num_words):
        register_words_recv = list(ffi.cast(" uint32_t[%d]" % num_words, register_words))
        num_words_recv = num_words
        key_cbr = str(protocol_handle)+str(endpoint)+"register_readback"  
        EP.cb_recv[key_cbr] = register_words_recv, num_words_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_register_readback_callback(self, register_readback_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "register_readback_callback_userlev", register_readback_callback_userlev)

    @ffi.def_extern()
    def burst_read_callback(context, protocol_handle, endpoint, status_word, data, num_data_words):
        status_word_recv = status_word
        data_recv = list(ffi.cast(" uint16_t[%d]" % num_data_words, data))
        num_data_words_recv = num_data_words
        key_cbr = str(protocol_handle)+str(endpoint)+"burst_read"  
        EP.cb_recv[key_cbr] = data_recv, status_word_recv, num_data_words_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_burst_read_callback(self, burst_read_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "burst_read_callback_userlev", burst_read_callback_userlev)

    @ffi.def_extern()
    def spi_mode_callback(context, protocol_handle, endpoint, quad_spi):
        quad_spi_recv = quad_spi
        key_cbr = str(protocol_handle)+str(endpoint)+"spi_mode"  
        EP.cb_recv[key_cbr] = quad_spi_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_spi_mode_callback(self, spi_mode_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "spi_mode_callback_userlev", spi_mode_callback_userlev)

    @ffi.def_extern()
    def supply_status_callback(context, protocol_handle, endpoint, supply_line, supply_status):
        Supply_Status = namedtuple('Supply_Status', 'voltage_uV current_uA power_nW')
        supply_line_recv = supply_line
        supply_status_recv = Supply_Status(
            voltage_uV = supply_status.voltage_uV,
            current_uA = supply_status.current_uA,
            power_nW = supply_status.power_nW
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"supply_status"  
        EP.cb_recv[key_cbr] = supply_line_recv, supply_status_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_supply_status_callback(self, supply_status_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "supply_status_callback_userlev", supply_status_callback_userlev)

    @ffi.def_extern()
    def irq_level_callback(context, protocol_handle, endpoint, irq_level):
        irq_level_recv = irq_level
        key_cbr = str(protocol_handle)+str(endpoint)+"irq_level"  
        EP.cb_recv[key_cbr] = irq_level_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_irq_level_callback(self, irq_level_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "irq_level_callback_userlev", irq_level_callback_userlev)

    @ffi.def_extern()
    def high_speed_compensation_callback(context, protocol_handle, endpoint, high_speed_compensation):
        high_speed_compensation_recv = high_speed_compensation
        key_cbr = str(protocol_handle)+str(endpoint)+"high_speed_compensation"  
        EP.cb_recv[key_cbr] = high_speed_compensation_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_high_speed_compensation_callback(self, high_speed_compensation_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "high_speed_compensation_callback_userlev", high_speed_compensation_callback_userlev)

    @ffi.def_extern()
    def quad_spi_wait_cycles_callback(context, protocol_handle, endpoint, quad_spi_wait_cycles):
        quad_spi_wait_cycles_recv = quad_spi_wait_cycles
        key_cbr = str(protocol_handle)+str(endpoint)+"quad_spi_wait_cycles"  
        EP.cb_recv[key_cbr] = quad_spi_wait_cycles_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_quad_spi_wait_cycles_callback(self, quad_spi_wait_cycles_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "quad_spi_wait_cycles_callback_userlev", quad_spi_wait_cycles_callback_userlev)


    def setup_callbacks(self):
        lib.ep_hal_bgt60trxx_set_callback_register_readback(lib.register_readback_callback, ffi.NULL)
        lib.ep_hal_bgt60trxx_set_callback_burst_read(lib.burst_read_callback, ffi.NULL)
        lib.ep_hal_bgt60trxx_set_callback_spi_mode(lib.spi_mode_callback, ffi.NULL)
        lib.ep_hal_bgt60trxx_set_callback_supply_status(lib.supply_status_callback, ffi.NULL)
        lib.ep_hal_bgt60trxx_set_callback_irq_level(lib.irq_level_callback, ffi.NULL)
        lib.ep_hal_bgt60trxx_set_callback_high_speed_compensation(lib.high_speed_compensation_callback, ffi.NULL)
        lib.ep_hal_bgt60trxx_set_callback_quad_spi_wait_cycles(lib.quad_spi_wait_cycles_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_hal_bgt60trxx_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def generate_reset_condition(self):
        self.check_return_code(lib.ep_hal_bgt60trxx_generate_reset_condition(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))

    def write_spi_words(self, spi_words, num_words, readback):
        lib.ep_hal_bgt60trxx_set_callback_register_readback(lib.register_readback_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_write_spi_words(
                    self.communication_protocol_handle,
                    self.epindex,
                    spi_words,
                     num_words,
                     readback))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"register_readback"]

    def do_spi_burst_read(self, burst_command_word, num_burst_words):
        lib.ep_hal_bgt60trxx_set_callback_burst_read(lib.burst_read_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_do_spi_burst_read(
                    self.communication_protocol_handle,
                    self.epindex,
                    burst_command_word,
                     num_burst_words))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"burst_read"]

    def is_using_quad_spi(self):
        lib.ep_hal_bgt60trxx_set_callback_spi_mode(lib.spi_mode_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_is_using_quad_spi(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"spi_mode"]

    def use_quad_spi(self, quad_spi):
        lib.ep_hal_bgt60trxx_set_callback_spi_mode(lib.spi_mode_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_use_quad_spi(
                    self.communication_protocol_handle,
                    self.epindex,
                    quad_spi))

    def get_supply_status(self, supply_line):
        lib.ep_hal_bgt60trxx_set_callback_supply_status(lib.supply_status_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_get_supply_status(
                    self.communication_protocol_handle,
                    self.epindex,
                    supply_line))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"supply_status"]

    def enable_irq(self, enable):
        self.check_return_code(lib.ep_hal_bgt60trxx_enable_irq(
                    self.communication_protocol_handle,
                    self.epindex,
                    enable))

    def read_irq_level(self):
        lib.ep_hal_bgt60trxx_set_callback_irq_level(lib.irq_level_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_read_irq_level(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"irq_level"]

    def is_high_speed_compensation_needed(self):
        lib.ep_hal_bgt60trxx_set_callback_high_speed_compensation(lib.high_speed_compensation_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_is_high_speed_compensation_needed(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"high_speed_compensation"]

    def get_quad_spi_wait_cycles(self):
        lib.ep_hal_bgt60trxx_set_callback_quad_spi_wait_cycles(lib.quad_spi_wait_cycles_callback, ffi.NULL)
        self.check_return_code(lib.ep_hal_bgt60trxx_get_quad_spi_wait_cycles(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"quad_spi_wait_cycles"]

    def enable_power_supply(self, enable):
        self.check_return_code(lib.ep_hal_bgt60trxx_enable_power_supply(
                    self.communication_protocol_handle,
                    self.epindex,
                    enable))
