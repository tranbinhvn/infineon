
# file: RadarBGT6x.py    ( Generated Automatically by pyUtility_python_code_gen.py )
#
# This python class wraps the API for the Avian device
# for EndpointRadarBGT6x
#
# ===========================================================================
# Copyright (C) 2014-2021 Infineon Technologies AG
# All rights reserved.
# ===========================================================================
#
# ===========================================================================
# This document contains proprietary information of Infineon Technologies AG.
# Passing on and copying of this document, and communication of its contents
# is not permitted without Infineon's prior written authorisation.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ===========================================================================

from . import EP, ffi, lib
from collections import namedtuple


class RadarBGT6x(EP):
    description = "ifxRadar BGT6x"
    def __init__(self, communication_protocol_handle, epindex):
        super().__init__(communication_protocol_handle, epindex)

    @ffi.def_extern()
    def adc_bgt6x_samplerate_callback(context, protocol_handle, endpoint, samplerate_Hz):
        samplerate_Hz_recv = samplerate_Hz
        key_cbr = str(protocol_handle)+str(endpoint)+"adc_bgt6x_samplerate"  
        EP.cb_recv[key_cbr] = samplerate_Hz_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_adc_bgt6x_samplerate_callback(self, adc_bgt6x_samplerate_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "adc_bgt6x_samplerate_callback_userlev", adc_bgt6x_samplerate_callback_userlev)

    @ffi.def_extern()
    def adc_bgt6x_configuration_callback(context, protocol_handle, endpoint, configuration):
        Configuration = namedtuple('Configuration', 'samplerate_Hz sample_time tracking double_msb_time oversampling')
        configuration_recv = Configuration(
            samplerate_Hz = configuration.samplerate_Hz,
            sample_time = configuration.sample_time,
            tracking = configuration.tracking,
            double_msb_time = configuration.double_msb_time,
            oversampling = configuration.oversampling
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"adc_bgt6x_configuration"  
        EP.cb_recv[key_cbr] = configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_adc_bgt6x_configuration_callback(self, adc_bgt6x_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "adc_bgt6x_configuration_callback_userlev", adc_bgt6x_configuration_callback_userlev)

    @ffi.def_extern()
    def tx_mode_callback(context, protocol_handle, endpoint, tx_mode):
        tx_mode_recv = tx_mode
        key_cbr = str(protocol_handle)+str(endpoint)+"tx_mode"  
        EP.cb_recv[key_cbr] = tx_mode_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_tx_mode_callback(self, tx_mode_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "tx_mode_callback_userlev", tx_mode_callback_userlev)

    @ffi.def_extern()
    def baseband_configuration_callback(context, protocol_handle, endpoint, configuration):
        Configuration = namedtuple('Configuration', 'hp_gain_1 hp_cutoff_1 vga_gain_1 hp_gain_2 hp_cutoff_2 vga_gain_2 hp_gain_3 hp_cutoff_3 vga_gain_3 hp_gain_4 hp_cutoff_4 vga_gain_4 reset_timer_period_100ps')
        configuration_recv = Configuration(
            hp_gain_1 = configuration.hp_gain_1,
            hp_cutoff_1 = configuration.hp_cutoff_1,
            vga_gain_1 = configuration.vga_gain_1,
            hp_gain_2 = configuration.hp_gain_2,
            hp_cutoff_2 = configuration.hp_cutoff_2,
            vga_gain_2 = configuration.vga_gain_2,
            hp_gain_3 = configuration.hp_gain_3,
            hp_cutoff_3 = configuration.hp_cutoff_3,
            vga_gain_3 = configuration.vga_gain_3,
            hp_gain_4 = configuration.hp_gain_4,
            hp_cutoff_4 = configuration.hp_cutoff_4,
            vga_gain_4 = configuration.vga_gain_4,
            reset_timer_period_100ps = configuration.reset_timer_period_100ps
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"baseband_configuration"  
        EP.cb_recv[key_cbr] = configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_baseband_configuration_callback(self, baseband_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "baseband_configuration_callback_userlev", baseband_configuration_callback_userlev)

    @ffi.def_extern()
    def phase_configuration_callback(context, protocol_handle, endpoint, configuration):
        Configuration = namedtuple('Configuration', 'lo_mod_1_en lo_mod_1_ph lo_mod_2_en lo_mod_2_ph')
        configuration_recv = Configuration(
            lo_mod_1_en = configuration.lo_mod_1_en,
            lo_mod_1_ph = configuration.lo_mod_1_ph,
            lo_mod_2_en = configuration.lo_mod_2_en,
            lo_mod_2_ph = configuration.lo_mod_2_ph
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"phase_configuration"  
        EP.cb_recv[key_cbr] = configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_phase_configuration_callback(self, phase_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "phase_configuration_callback_userlev", phase_configuration_callback_userlev)

    @ffi.def_extern()
    def baseband_test_configuration_callback(context, protocol_handle, endpoint, configuration):
        Configuration = namedtuple('Configuration', 'rx_mask frequency_Hz')
        configuration_recv = Configuration(
            rx_mask = configuration.rx_mask,
            frequency_Hz = configuration.frequency_Hz
            )
        key_cbr = str(protocol_handle)+str(endpoint)+"baseband_test_configuration"  
        EP.cb_recv[key_cbr] = configuration_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_baseband_test_configuration_callback(self, baseband_test_configuration_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "baseband_test_configuration_callback_userlev", baseband_test_configuration_callback_userlev)

    @ffi.def_extern()
    def dumped_registers_callback(context, protocol_handle, endpoint, registers, num_registers):
        registers_recv = list(ffi.cast(" uint32_t[%d]" % num_registers, registers))
        num_registers_recv = num_registers
        key_cbr = str(protocol_handle)+str(endpoint)+"dumped_registers"  
        EP.cb_recv[key_cbr] = registers_recv, num_registers_recv ## direct return mechanism ( no user callbacks is called ! )
        

    def set_dumped_registers_callback(self, dumped_registers_callback_userlev):
        EP.set_user_callback(self.communication_protocol_handle, "dumped_registers_callback_userlev", dumped_registers_callback_userlev)


    def setup_callbacks(self):
        lib.ep_radar_bgt6x_set_callback_adc_samplerate(lib.adc_bgt6x_samplerate_callback, ffi.NULL)
        lib.ep_radar_bgt6x_set_callback_adc_configuration(lib.adc_bgt6x_configuration_callback, ffi.NULL)
        lib.ep_radar_bgt6x_set_callback_tx_mode(lib.tx_mode_callback, ffi.NULL)
        lib.ep_radar_bgt6x_set_callback_baseband_configuration(lib.baseband_configuration_callback, ffi.NULL)
        lib.ep_radar_bgt6x_set_callback_phase_configuration(lib.phase_configuration_callback, ffi.NULL)
        lib.ep_radar_bgt6x_set_callback_baseband_test_configuration(lib.baseband_test_configuration_callback, ffi.NULL)
        lib.ep_radar_bgt6x_set_callback_dumped_registers(lib.dumped_registers_callback, ffi.NULL)

    def is_compatible_endpoint(self):
        self.check_return_code(lib.ep_radar_bgt6x_is_compatible_endpoint(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        print("%s is compatible OK." % type(self).description)

    def set_adc_samplerate(self, samplerate_Hz):
        self.check_return_code(lib.ep_radar_bgt6x_set_adc_samplerate(
                    self.communication_protocol_handle,
                    self.epindex,
                    samplerate_Hz))

    def get_adc_samplerate(self):
        lib.ep_radar_bgt6x_set_callback_adc_samplerate(lib.adc_bgt6x_samplerate_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_adc_samplerate(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"adc_bgt6x_samplerate"]

    def set_adc_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt6x_set_adc_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_adc_configuration(self):
        lib.ep_radar_bgt6x_set_callback_adc_configuration(lib.adc_bgt6x_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_adc_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"adc_bgt6x_configuration"]

    def set_tx_mode(self, tx_mode):
        self.check_return_code(lib.ep_radar_bgt6x_set_tx_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    tx_mode))

    def get_tx_mode(self):
        lib.ep_radar_bgt6x_set_callback_tx_mode(lib.tx_mode_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_tx_mode(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"tx_mode"]

    def set_baseband_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt6x_set_baseband_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_baseband_configuration(self):
        lib.ep_radar_bgt6x_set_callback_baseband_configuration(lib.baseband_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_baseband_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"baseband_configuration"]

    def set_phase_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt6x_set_phase_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_phase_configuration(self):
        lib.ep_radar_bgt6x_set_callback_phase_configuration(lib.phase_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_phase_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"phase_configuration"]

    def do_calibration(self, calibrate_phase, calibrate_baseband):
        self.check_return_code(lib.ep_radar_bgt6x_do_calibration(
                    self.communication_protocol_handle,
                    self.epindex,
                    calibrate_phase,
                     calibrate_baseband))

    def set_baseband_test_configuration(self, configuration_cffi_struct):
        self.check_return_code(lib.ep_radar_bgt6x_set_baseband_test_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    configuration_cffi_struct))

    def get_baseband_test_configuration(self):
        lib.ep_radar_bgt6x_set_callback_baseband_test_configuration(lib.baseband_test_configuration_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_baseband_test_configuration(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"baseband_test_configuration"]

    def get_dumped_registers(self):
        lib.ep_radar_bgt6x_set_callback_dumped_registers(lib.dumped_registers_callback, ffi.NULL)
        self.check_return_code(lib.ep_radar_bgt6x_get_dumped_registers(
                    self.communication_protocol_handle,
                    self.epindex,
                    ))
        return EP.cb_recv[str(self.communication_protocol_handle)+str(self.epindex)+"dumped_registers"]
